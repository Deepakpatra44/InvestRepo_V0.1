﻿using System;
using System.ComponentModel.DataAnnotations;
namespace InvestorAPI.Model
{
    public class Investor
    {
      //  public int Id { get; set; }
        [Required]
        [MaxLength(100,ErrorMessage = "Name cannot exceed 100 characters")]
        public string Name { get; set; }
        public string Phone { get; set; }
        [Display (Name = "Mail ID")]
        [RegularExpression(@"^[a-zA-Z0-9._\\-]+@[a-zA-Z0-9]+(([\\-]*[a-zA-Z0-9]+)*[.][a-zA-Z0-9]+)+(;[ ]*[a-zA-Z0-9._\\-]+@[a-zA-Z0-9]+(([\\-]*[a-zA-Z0-9]+)*[.][a-zA-Z0-9]+)+)*$", ErrorMessage ="Invalid Mail format")]
        public string Email { get; set; }
        public string Country { get; set; }

        public List<Fund> Funds { get; set; } = new();

    }
}
