﻿using InvestorAPI.Model;
using InvestorAPI.Repositories;
using Xunit;

namespace InvestorAPI.Tests
{
    public class InvestorRepositoryTests
    {
        //Unit test

        [Fact]
        public async Task Can_Add_Investor()
        {
            var repo = new InvestorRepository();
            var investor = new Investor { Name = "Deepak", Phone = "(684) 842-2371", Email = "deepakranjan455@mail.com", Country = "India", Funds = new List<Fund> { new Fund { Name = "Max life fund" } }  };

            await repo.AddAsync(investor);

            var result = await repo.GetByNameAsync("Test");

            Assert.NotNull(result);
            Assert.Equal("Test", result.Name);
        }
    }
}
