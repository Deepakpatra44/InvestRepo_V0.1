﻿using InvestorAPI.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;


namespace InvestorAPI.Repositories
{
    public class InvestorRepository : IInvestorRepository
    {
        private readonly List<Investor> _investors = new()
    {
        new Investor { Name = "Keely Newman", Phone = "1-786-738-4711", Email = "in.magna@yahoo.com", Country = "USA", Funds = new List<Fund>{ new Fund{ Name="Mauris LLP"}, new Fund{ Name="Nullam Velit Fund"} }},
        new Investor { Name = "Kimberly Maldonado", Phone = "(684) 842-2371", Email = "non.lacinia@outlook.org", Country = "Spain", Funds = new List<Fund>{ new Fund{ Name="Nullam Velit Fund"} }},
        new Investor { Name = "Sean Massey", Phone = "(548) 250-4693", Email = "pharetra.quisque.ac@outlook.edu", Country = "Ireland", Funds = new List<Fund>{ new Fund{ Name="Mauris LLP"}, new Fund{ Name="Ligula Aenean Fund"}, new Fund{ Name="Mauris Sit Amet Fund"} }},
        new Investor { Name = "Nyssa Barr", Phone = "(673) 581-3597", Email = "odio@aol.couk", Country = "Canada", Funds = new List<Fund>{ new Fund{ Name="Ullamcorper Viverra Fund"} }}
    };
      
        //Task 1 
        public Task<IEnumerable<Investor>> GetAllAsync()
        {
           return Task.FromResult(_investors.AsEnumerable());
        }

        //Task 2
        public Task<Investor> GetByNameAsync(string name)
        { 
            return Task.FromResult(_investors.FirstOrDefault(i => i.Name == name));
        }

        //Task 3
        public Task<bool> AddFundAsync(string investorName, string fundName)
        {
            var investor = _investors.FirstOrDefault(i => i.Name == investorName);
            if (investor == null) return Task.FromResult(false);
            if (!investor.Funds.Any(f => f.Name == fundName))
            {
                investor.Funds.Add(new Fund { Name = fundName });
            }
            return Task.FromResult(true);
        }

        //Task 4
        public Task AddAsync(Investor investor)
        {
            _investors.Add(investor);
            return Task.CompletedTask;
        }

        //Task 5
        public Task<bool> DeleteAsync(string name)
        {
            var investor = _investors.FirstOrDefault(i => i.Name == name);
            if (investor == null) return Task.FromResult(false);
            _investors.Remove(investor);
            return Task.FromResult(true);
        }

      
    }
}
