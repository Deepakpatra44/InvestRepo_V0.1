﻿using InvestorAPI.Model;

namespace InvestorAPI.Repositories
{
    public interface IInvestorRepository
    {
        Task<IEnumerable<Investor>> GetAllAsync();
        Task<Investor> GetByNameAsync(string name);
        Task AddAsync(Investor investor);
        Task<bool> DeleteAsync(string name);
        Task<bool> AddFundAsync(string investorName, string fundName);
    }
}
