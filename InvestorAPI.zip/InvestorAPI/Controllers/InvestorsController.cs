﻿
using InvestorAPI.DTO;
using InvestorAPI.Model;
using InvestorAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InvestorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvestorsController : ControllerBase
    {
        private readonly IInvestorRepository _repository;
        //Logger used 
        private readonly ILogger<InvestorsController> _logger;

        public InvestorsController(IInvestorRepository repository, ILogger<InvestorsController> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        //async Task
        //Task 1 Retrieve all investors 
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var investors = await _repository.GetAllAsync();
            return Ok(investors);
        }

        //Task 2 Retrieve a single investor

        [HttpGet("{name}")]
        public async Task<IActionResult> GetByName(string name)
        {
            var investor = await _repository.GetByNameAsync(name);
            if (investor == null) return NotFound();
            return Ok(investor);
        }

        // Task 3 Add fund

        [HttpPut("{name}/add-fund")]
        public async Task<IActionResult> AddFund(string name, [FromQuery] string fund)
        {
            var result = await _repository.AddFundAsync(name, fund);
            if (!result) return NotFound();
            return NoContent();
           
        }

        //Task 4 Create a new investor

        //DTO used

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] InvestorDto dto)
        {
            //Model Validation checked
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var investor = new Investor
            {
                Name = dto.Name,
                Phone = dto.Phone,
                Email = dto.Email,
                Country = dto.Country,
                Funds = dto.Funds.Select(f => new Fund { Name = f }).ToList()
            };

            await _repository.AddAsync(investor);
            return CreatedAtAction(nameof(GetByName), new { name = dto.Name }, investor);
        }

        //Task 5 Delete Investor
        [HttpDelete("{name}")]
        public async Task<IActionResult> Delete(string name)
        {
            var result = await _repository.DeleteAsync(name);
            if (!result) return NotFound();
            return NoContent();
        }
        
    }
}
