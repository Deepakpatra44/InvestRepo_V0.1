﻿using System.ComponentModel.DataAnnotations;

namespace InvestorAPI.DTO
{
    public class InvestorDto
    { 
            [Required]
            public string Name { get; set; }
            [Phone]
            public string Phone { get; set; }
            [EmailAddress]
            public string Email { get; set; }
            public string Country { get; set; }
            public List<string> Funds { get; set; }
        
    }
}
